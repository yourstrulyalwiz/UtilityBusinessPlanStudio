import { useState } from "react";
import { Link, useParams, useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetUtility, getGetUtilityQueryKey, useUpdateUtility, useDeleteUtility, useAddMember, useRemoveMember, useListUsers, getListUsersQueryKey,
  useGetPlan, getGetPlanQueryKey, useGetModulePlan, getGetModulePlanQueryKey,
  getListUtilitiesQueryKey, getGetSummaryQueryKey, getListAuditQueryKey, type MemberInputMemberRole, type UtilityUpdate,
} from "@workspace/api-client-react";
import { ArrowLeft, FileText, Pencil, Trash2, UserPlus, Users } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Card, Empty, ErrorState, Pill, statusTone, Btn, Field, inputCls, Wave } from "@/components/kit";
import { LogoPicker } from "@/components/utility-form";
import { ModuleOverview } from "@/components/module-overview";
import { useMe, errMsg, logoUrl, initials, humanize, fmtDate, fmtDateTime, MEMBER_ROLE_LABEL } from "@/lib/app";
import { useToast } from "@/hooks/use-toast";

export default function UtilityPage() {
  const { id: routeId = "", planId = "" } = useParams<{ id?: string; planId?: string }>();
  const me = useMe();
  const qc = useQueryClient();
  const [,navigate] = useLocation();
  const [deleting,setDeleting] = useState(false);
  const [confirmationName,setConfirmationName] = useState("");
  const { toast } = useToast();
  const planQuery = useGetPlan(planId, { query: { enabled: !!planId, queryKey: getGetPlanQueryKey(planId) } });
  const utilityQuery = useGetUtility(routeId, { query: { enabled: !!routeId, queryKey: getGetUtilityQueryKey(routeId) } });
  const q = planId ? planQuery : utilityQuery;
  const id = routeId || q.data?.utility.id || "";
  const canManage = me.role === "admin" || me.role === "ttl";
  const users = useListUsers({ query: { enabled: canManage, queryKey: getListUsersQueryKey() } });
  const wfPlanId = planId || q.data?.utility.planId || "";
  const mp = useGetModulePlan(wfPlanId, { query: { enabled: !!wfPlanId, queryKey: getGetModulePlanQueryKey(wfPlanId) } });
  const [editing, setEditing] = useState(false);
  const [adding, setAdding] = useState(false);
  const [newMember, setNewMember] = useState<{ userId: string; memberRole: MemberInputMemberRole }>({ userId: "", memberRole: "team" });
  const [form, setForm] = useState<UtilityUpdate>({});

  const refresh = () => {
    qc.invalidateQueries({ queryKey: getGetUtilityQueryKey(id) });
    qc.invalidateQueries({ queryKey: getGetPlanQueryKey(planId || q.data?.utility.planId || "") });
    qc.invalidateQueries({ queryKey: getListUtilitiesQueryKey() });
    qc.invalidateQueries({ queryKey: getGetSummaryQueryKey() });
    qc.invalidateQueries({ queryKey: getListAuditQueryKey() });
  };
  const onErr = (title: string) => (e: unknown) => toast({ title, description: errMsg(e), variant: "destructive" });
  const deletion = useDeleteUtility({mutation:{
    onSuccess:()=>{
      setDeleting(false);
      navigate("/admin");
      qc.removeQueries({queryKey:getGetUtilityQueryKey(id)});
      qc.removeQueries({queryKey:getGetPlanQueryKey(wfPlanId)});
      qc.removeQueries({queryKey:getGetModulePlanQueryKey(wfPlanId)});
      qc.invalidateQueries({queryKey:getListUtilitiesQueryKey()});
      qc.invalidateQueries({queryKey:getGetSummaryQueryKey()});
      qc.invalidateQueries({queryKey:getListAuditQueryKey()});
      toast({title:"Utility deleted"});
    },onError:onErr("Could not delete utility")
  }});
  const update = useUpdateUtility({ mutation: { onSuccess: () => { refresh(); setEditing(false); toast({ title: "Utility updated" }); }, onError: onErr("Update failed") } });
  const add = useAddMember({ mutation: { onSuccess: () => { refresh(); setAdding(false); setNewMember({ userId: "", memberRole: "team" }); toast({ title: "Team member added" }); }, onError: onErr("Could not add member") } });
  const remove = useRemoveMember({ mutation: { onSuccess: () => { refresh(); toast({ title: "Team member removed" }); }, onError: onErr("Could not remove member") } });

  if (q.isLoading) return <div className="space-y-4"><div className="h-28 animate-pulse rounded-xl border bg-card" /><div className="h-96 animate-pulse rounded-xl border bg-card" /></div>;
  if (q.isError || !q.data) return <Card><ErrorState message={errMsg(q.error, "Utility not found or you do not have access.")} onRetry={() => q.refetch()} /></Card>;
  const { utility: u, members, audit } = q.data;
  const memberEmails = new Set(members.map((m) => m.email));
  const candidates = (users.data ?? []).filter((p) => p.isActive && !memberEmails.has(p.email));
  const ttls = (users.data ?? []).filter((p) => (p.role === "ttl" || p.id === "00000000-0000-4000-8000-000000000001") && p.isActive);

  return (
    <div>
      <Link href={me.role === "admin" ? "/admin" : "/"} className="mb-5 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-[#323D4F]" data-testid="link-back"><ArrowLeft className="h-4 w-4" /> Back to registry</Link>
      <Card className="rise mb-6 p-6">
        <div className="flex flex-col gap-5 md:flex-row md:items-start">
          <div className="flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-xl border bg-white text-lg font-semibold text-[#323D4F]">
            {u.logoPath ? <img src={logoUrl(u.logoPath)!} alt={`${u.name} logo`} className="h-full w-full object-contain p-1.5" /> : initials(u.shortName || u.name)}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-2xl font-semibold tracking-tight text-[#323D4F]" data-testid="text-utility-name">{u.name}</h1>
              {u.shortName && <Pill tone="navy">{u.shortName}</Pill>}
              <Pill tone={statusTone(u.status)}>{humanize(u.status)}</Pill>
            </div>
            <div className="mt-1 text-sm text-muted-foreground">{u.serviceArea} · {u.countryName} · {u.region}</div>
            <dl className="mt-4 grid grid-cols-2 gap-x-6 gap-y-3 text-sm sm:grid-cols-4">
              {[["TTL", u.ttlName], ["Plan year", u.planId && u.planYear ? String(u.planYear) : "–"], ["Currency", u.currency], ["WB project", u.wbProjectId || "—"], ["Plan status", u.planId ? humanize(u.planStatus) : "No business plan"], ["Current module", u.currentPhase || "—"], ["Registered", fmtDate(u.createdAt)]].map(([k, v]) => (
                <div key={k}><dt className="text-[11px] uppercase tracking-wider text-muted-foreground">{k}</dt><dd className="mt-0.5 font-medium text-[#323D4F]">{v}</dd></div>
              ))}
            </dl>
          </div>
          <div className="flex shrink-0 flex-col items-stretch gap-2 md:w-48">
            <div className="rounded-lg border border-[#1ED3D9]/15 bg-[#E4F8F9]/60 p-3">
              <div className="flex justify-between text-xs"><span className="text-muted-foreground">Workflow progress</span><span className="font-semibold text-[#323D4F] tnum">{Math.round(u.progress)}%</span></div>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white"><div className="h-full rounded-full bg-gradient-to-r from-[#127A80] to-[#1ED3D9]" style={{ width: `${Math.min(100, u.progress)}%` }} /></div>
            </div>
            {u.planId && <Tooltip>
              <TooltipTrigger asChild><a href={`/api/plans/${u.planId}/deck`} className="flex h-10 w-full items-center justify-center gap-2 rounded-lg border bg-white text-sm font-medium text-[#323D4F] hover:bg-muted" data-testid="button-deck"><FileText className="h-4 w-4" /> Registry summary deck</a></TooltipTrigger>
              <TooltipContent>Registry information only. This is not a complete business plan; use Module 8 outputs for module data.</TooltipContent>
            </Tooltip>}
            {me.role === "admin" && <Btn variant="navy" onClick={() => { setForm({ name: u.name, shortName: u.shortName, serviceArea: u.serviceArea, ttlUserId: u.ttlUserId, wbProjectId: u.wbProjectId, status: u.status === "archived" ? "archived" : "active", logoPath: u.logoPath }); setEditing(true); }} data-testid="button-edit-utility"><Pencil className="h-4 w-4" /> Edit details</Btn>}
          </div>
        </div>
      </Card>

      <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
        <div>
          {!wfPlanId && q.data ? <Card data-testid="state-no-plan"><Empty icon={<FileText className="h-6 w-6" />} title="No business plan" body="This utility has no business plan. Its registry details, team and history remain available. No plan is created automatically." /></Card> : mp.isLoading ? <div className="h-96 animate-pulse rounded-xl border bg-card" /> : mp.isError || !mp.data ? <Card><ErrorState message={errMsg(mp.error, "Module plan unavailable.")} onRetry={() => mp.refetch()} /></Card> : <ModuleOverview plan={mp.data} />}
        </div>

        <div className="space-y-6">
          <Card>
            <div className="flex items-center justify-between border-b px-5 py-3">
              <h2 className="text-sm font-semibold text-[#323D4F]">Team</h2>
              {canManage && <Btn variant="ghost" className="h-8 px-2 text-[#127A80]" onClick={() => setAdding(true)} data-testid="button-add-member"><UserPlus className="h-4 w-4" /> Add</Btn>}
            </div>
            {members.length === 0 ? <Empty icon={<Users className="h-5 w-5" />} title="No team members" body={canManage ? "Add the utility focal point, team members and consultants." : "No one has been assigned yet."} /> : (
              <ul className="divide-y">
                {members.map((m) => (
                  <li key={m.id} className="group flex items-center gap-3 px-5 py-3" data-testid={`member-${m.id}`}>
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#323D4F]/[.07] text-[11px] font-semibold text-[#323D4F]">{initials(m.fullName)}</div>
                    <div className="min-w-0 flex-1"><div className="truncate text-sm font-medium text-[#323D4F]">{m.fullName}</div><div className="truncate text-xs text-muted-foreground">{MEMBER_ROLE_LABEL[m.memberRole] ?? humanize(m.memberRole)}</div></div>
                    {canManage && <button disabled={remove.isPending} onClick={() => { if (confirm(`Remove ${m.fullName} from this team?`)) remove.mutate({ id, memberId: m.id }); }} className="rounded p-1 text-muted-foreground opacity-0 hover:text-destructive group-hover:opacity-100" aria-label="Remove member" data-testid={`button-remove-member-${m.id}`}><Trash2 className="h-4 w-4" /></button>}
                  </li>
                ))}
              </ul>
            )}
          </Card>
          <Card>
            <div className="border-b px-5 py-3"><h2 className="text-sm font-semibold text-[#323D4F]">Recent history</h2></div>
            {audit.length === 0 ? <div className="px-5 py-8 text-center text-xs text-muted-foreground">No recorded changes yet.</div> : (
              <ol className="relative space-y-4 px-5 py-4">
                {audit.slice(0, 12).map((a) => (
                  <li key={a.id} className="relative pl-5"><span className="absolute left-0 top-1.5 h-2 w-2 rounded-full bg-[#1ED3D9]" />
                    <div className="text-[13px] text-[#323D4F]"><strong className="font-medium">{a.actor}</strong> {humanize(a.action).toLowerCase()}</div>
                    <div className="text-[11px] text-muted-foreground">{fmtDateTime(a.createdAt)}</div>
                  </li>
                ))}
              </ol>
            )}
            <Wave className="opacity-40" />
          </Card>
        </div>
      </div>

      {me.role==="admin" && <Card className="mt-6 border-destructive/30 p-5">
        <h2 className="font-semibold">Delete utility</h2>
        <p className="mt-1 text-sm text-muted-foreground">Permanently remove this utility and its plans. To keep the data, use Edit details → Status → Archived instead.</p>
        <Btn variant="outline" className="mt-3 border-destructive/40 text-destructive" onClick={()=>{setConfirmationName("");setDeleting(true);}} data-testid="button-delete-utility"><Trash2 className="h-4 w-4"/> Delete utility</Btn>
      </Card>}
      <Dialog open={deleting && me.role==="admin"} onOpenChange={(open)=>{if(!deletion.isPending)setDeleting(open);}}>
        <DialogContent className="max-w-lg rounded-xl">
          <DialogHeader><DialogTitle>Delete {u.name}?</DialogTitle><DialogDescription>This cannot be undone in the app. All annual plans, modules, comments, team assignments and archived legacy copies will be deleted. User accounts and administrative audit history will remain. Uploaded logo files are not erased from storage.</DialogDescription></DialogHeader>
          <p className="text-sm">Download any plan data or legacy copies you need before continuing. Archiving is the safer alternative if you may need this utility again.</p>
          <form className="space-y-4" onSubmit={e=>{e.preventDefault();if(confirmationName===u.name&&!deletion.isPending)deletion.mutate({id,data:{confirmationName}});}}>
            <Field label={`Type the exact utility name: ${u.name}`} required><input className={inputCls} autoComplete="off" value={confirmationName} onChange={e=>setConfirmationName(e.target.value)} disabled={deletion.isPending} data-testid="input-delete-confirmation"/></Field>
            <div className="flex flex-wrap justify-end gap-2">
              <Btn type="button" variant="ghost" disabled={deletion.isPending} onClick={()=>setDeleting(false)}>Cancel</Btn>
              <Btn type="submit" className="bg-destructive text-white hover:bg-destructive/90" disabled={deletion.isPending||confirmationName!==u.name} data-testid="button-confirm-delete-utility">{deletion.isPending?"Deleting…":"Permanently delete"}</Btn>
            </div>
          </form>
        </DialogContent>
      </Dialog>
      <Dialog open={adding} onOpenChange={setAdding}>
        <DialogContent className="max-w-md rounded-xl">
          <DialogHeader><DialogTitle className="text-[#323D4F]">Add team member</DialogTitle><DialogDescription>Only people with Studio access can be assigned. Invite new people from People &amp; roles.</DialogDescription></DialogHeader>
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); if (newMember.userId) add.mutate({ id, data: newMember }); }}>
            <Field label="Person" required>
              <select className={inputCls} value={newMember.userId} onChange={(e) => setNewMember((s) => ({ ...s, userId: e.target.value }))} data-testid="select-member">
                <option value="">{users.isLoading ? "Loading…" : candidates.length ? "Select a person…" : "Everyone is already on this team"}</option>
                {candidates.map((p) => <option key={p.id} value={p.id}>{p.fullName} — {p.email}</option>)}
              </select>
            </Field>
            <Field label="Team role" required>
              <select className={inputCls} value={newMember.memberRole} onChange={(e) => setNewMember((s) => ({ ...s, memberRole: e.target.value as MemberInputMemberRole }))} data-testid="select-member-role">
                {Object.entries(MEMBER_ROLE_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </Field>
            <div className="flex justify-end gap-2"><Btn type="button" variant="ghost" onClick={() => setAdding(false)}>Cancel</Btn><Btn type="submit" disabled={!newMember.userId || add.isPending} data-testid="button-confirm-add-member">{add.isPending ? "Adding…" : "Add to team"}</Btn></div>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={editing} onOpenChange={setEditing}>
        <DialogContent className="max-h-[90dvh] max-w-lg overflow-auto rounded-xl">
          <DialogHeader><DialogTitle className="text-[#323D4F]">Edit utility</DialogTitle><DialogDescription>Country and plan year are fixed once registered.</DialogDescription></DialogHeader>
          <form className="space-y-4" onSubmit={(e) => {
            e.preventDefault();
            if (form.wbProjectId && !/^P\d{6}$/.test(form.wbProjectId)) { toast({ title: "WB project ID must be P followed by 6 digits", variant: "destructive" }); return; }
            update.mutate({ id, data: form });
          }}>
            <div className="grid gap-4 sm:grid-cols-[1fr_120px]">
              <Field label="Name" required><input required className={inputCls} value={form.name ?? ""} maxLength={200} onChange={(e) => setForm((s) => ({ ...s, name: e.target.value }))} data-testid="input-edit-name" /></Field>
              <Field label="Short name"><input className={inputCls} value={form.shortName ?? ""} maxLength={12} onChange={(e) => setForm((s) => ({ ...s, shortName: e.target.value }))} data-testid="input-edit-short-name" /></Field>
            </div>
            <Field label="Service area" required><input required className={inputCls} value={form.serviceArea ?? ""} onChange={(e) => setForm((s) => ({ ...s, serviceArea: e.target.value }))} data-testid="input-edit-service-area" /></Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Task Team Leader">
                <select className={inputCls} value={form.ttlUserId ?? ""} disabled={me.role !== "admin"} onChange={(e) => setForm((s) => ({ ...s, ttlUserId: e.target.value }))} data-testid="select-edit-ttl">
                  {!ttls.some((t) => t.id === form.ttlUserId) && <option value={form.ttlUserId}>{u.ttlName}</option>}
                  {ttls.map((t) => <option key={t.id} value={t.id}>{t.fullName}</option>)}
                </select>
              </Field>
              <Field label="WB project ID"><input className={inputCls} value={form.wbProjectId ?? ""} maxLength={7} onChange={(e) => setForm((s) => ({ ...s, wbProjectId: e.target.value.toUpperCase() }))} data-testid="input-edit-wb-project" /></Field>
            </div>
            <Field label="Status">
              <select className={inputCls} value={form.status} onChange={(e) => setForm((s) => ({ ...s, status: e.target.value as "active" | "archived" }))} data-testid="select-edit-status"><option value="active">Active</option><option value="archived">Archived</option></select>
            </Field>
            <Field label="Logo"><LogoPicker value={form.logoPath ?? null} onChange={(p) => setForm((s) => ({ ...s, logoPath: p }))} /></Field>
            <div className="flex justify-end gap-2 border-t pt-4"><Btn type="button" variant="ghost" onClick={() => setEditing(false)}>Cancel</Btn><Btn type="submit" disabled={update.isPending} data-testid="button-save-utility">{update.isPending ? "Saving…" : "Save changes"}</Btn></div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
